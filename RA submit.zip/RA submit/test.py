# from flask import Flask, redirect, url_for, request
#
# app = Flask(__name__)
# temp = []
#
#
# @app.route('/success/<name>')
# def success(name):
#     a = name
#     return 'quote data is  %s' % name
#
#
# @app.route('/login', methods=['POST', 'GET'])
# def login():
#     # print(temp)
#     if request.method == 'POST':
#         # user=request.form['nm']
#         # user1 = request.form['nm1']
#         Quote_no = request.form['Quote_no']
#         Part_Number = request.form['Part_Number']
#         Part_Name = request.form['Part_Name']
#         Alloy = request.form['Alloy']
#         Temper = request.form['Temper']
#         Profile = request.form['Profile']
#         Part_Size_Thickness = request.form['Part_Size_Thickness']
#         Part_Size_Width = request.form['Part_Size_Width']
#         Part_Size_Length = request.form['Part_Size_Length']
#         Part_Size_Weight = request.form['Part_Size_Weight']
#         Raw_Material_Thickness = request.form['Raw_Material_Thickness']
#         Raw_Material_Width = request.form['Raw_Material_Width']
#         Raw_Material_Length = request.form['Raw_Material_Length']
#         Raw_Material_Weight = request.form['Raw_Material_Weight']
#         Metal_removal = request.form['Metal_removal']
#         Removal_rate = request.form['Removal_rate']
#         Machine_Hours = request.form['Machine_Hours']
#         Machine_rate = request.form['Machine_rate']
#         Machining_price = request.form['Machining_price']
#         Material_dollar = request.form['Material_dollar']
#         Material_price = request.form['Material_price']
#         Treatment_Price = request.form['Treatment_Price']
#         temp.append(Quote_no)
#         temp.append(Part_Number)
#         temp.append(Part_Name)
#         temp.append(Alloy)
#         temp.append(Temper)
#         temp.append(Profile)
#         temp.append(Part_Size_Thickness)
#         temp.append(Part_Size_Width)
#         temp.append(Part_Size_Length)
#         temp.append(Part_Size_Weight)
#         temp.append(Raw_Material_Thickness)
#         temp.append(Raw_Material_Width)
#         temp.append(Raw_Material_Length)
#         temp.append(Raw_Material_Weight)
#         temp.append(Metal_removal)
#         temp.append(Removal_rate)
#         temp.append(Machine_Hours)
#         temp.append(Machine_rate)
#         temp.append(Machining_price)
#         temp.append(Material_dollar)
#         temp.append(Material_price)
#         temp.append(Treatment_Price)
#         # temp.append()
#         # temp.append()
#         print(temp)
#         # user1=request.form['nm1']
#         return redirect(url_for('success',
#                                 name=Quote_no + " " + Part_Number + " " + Part_Name + " " + Alloy + " " + Temper + " " + Profile + " " + Part_Size_Thickness + " " + Part_Size_Width + " " + Part_Size_Length +
#                                      " " + Part_Size_Weight + " " + Raw_Material_Thickness + " " + Raw_Material_Width + " "
#                                      + Raw_Material_Length + " " + Raw_Material_Weight + " " + Metal_removal + " " + Removal_rate + " " +
#                                      Machine_Hours + " " + Machine_rate + " " + Machining_price + " " + Material_dollar + " " + Material_price + " " + Treatment_Price))
#     else:
#         # user = request.args.get('nm')
#         # user1 = request.args.get('nm1')
#         # user1 = request.args.get('Quote_no')
#         return redirect(url_for('success',
#                                 name=Quote_no + " " + Part_Number + " " + Part_Name + " " + Alloy + " " + Temper + " " + Profile + " " + Part_Size_Thickness + " " + Part_Size_Width + " " + Part_Size_Length +
#                                      " " + Part_Size_Weight + " " + Raw_Material_Thickness + " " + Raw_Material_Width + " "
#                                      + Raw_Material_Length + " " + Raw_Material_Weight + " " + Metal_removal + " " + Removal_rate + " "
#                                      + Machine_Hours + " " + Machine_rate + " " + Machining_price + " " + Material_dollar + " " + Material_price + " " + Treatment_Price))
#
#
# if __name__ == '__main__':
#     app.run(debug=True ,port=5000,use_reloader=False)

import time
from flask import Flask, redirect, url_for, request
from flask import Flask, render_template, request, make_response
from openpyxl import load_workbook
from flask_cors import CORS
from flask import Flask;
import pandas as pd;
from pandas import DataFrame, read_csv;
import matplotlib.pyplot as plot
import os
from PIL import Image
import base64
import io
from matplotlib.ticker import MaxNLocator
import math
import statistics

HOST_NAME = "localhost"
HOST_PORT = 5000
app = Flask(__name__)
CORS(app)

# app = Flask(__name__)
temp = []

# def temp():
#
# @app.route("/",methods=["POST","GET"])

@app.route("/",methods=['POST','GET'])
def index():
    # if request.form["btn"] == "home":
    # print("entering")
    if request.method == 'POST':
        # print("entering inside post")
        Manufacturer2 = request.form['Manufacturer2']
        Model2 = request.form['Model2']
        Machine_name2=request.form['Machine_name2']
        Category2 = request.form['Category2']
        Form2 = request.form['Form2']
        Temper2 = request.form['Temper2']
        weightref = float(request.form['refweightbox'])
        weightref2 = float(request.form['refweightbox2'])

        delta = (weightref2 - weightref)/5

        # print(weightref)

        #weight ref to weight ref + delta
        bar1 = weightref+delta
        # weight ref + delta to weight ref + (2 * delta)
        bar2 = weightref+(2*delta)
        # weight ref + delta to weight ref + (2 * delta)
        bar3 = weightref+ (3 * delta)
        # weight ref + delta to weight ref + (2 * delta)
        bar4 = weightref + (4 * delta)
        # weight ref + delta to weight ref + (2 * delta)
        bar5 = weightref+ (5 * delta)



        # if weightref == 0:
        #     weightrefout = 0
        # elif weightref == 1:
        #     weightrefout = 1
        # elif weightref == 2:
        #     weightrefout = 2
        # elif weightref == 4:
        #     weightrefout = 4
        # elif weightref == 6:
        #     weightrefout = 6
        # elif weightref == 8:
        #     weightrefout = 8
        # elif weightref == 10:
        #     weightrefout = 10
        # elif weightref == 15:
        #     weightrefout = 15
        # elif weightref == 20:
        #     weightrefout = 20
        # elif weightref == 30:
        #     weightrefout = 30
        # elif weightref == 40:
        #     weightrefout = 40
        # elif weightref == 50:
        #     weightrefout = 50
        # elif weightref == 60:
        #     weightrefout = 60
        # elif weightref == 80:
        #     weightrefout = 80
        # elif weightref == 100:
        #     weightrefout = 100
        # elif weightref == 150:
        #     weightrefout = 150
        # elif weightref == 200:
        #     weightrefout = 200
        # elif weightref == 300:
        #     weightrefout = 300
        # else:
        #     weightrefout  = 0
        # print(weightrefout)

        # print(Form2)
        Alloy2=request.form['Alloy2']
        text_file1 = open("templates\index.html", "w")
        # text_file1 = open(r"C:\Users\saich\Desktop\quotation system\venv\templates\templates\index.html", "w")
        text_file1.write("")
        text_file1.close()
        # print(Manufacturer2)
        # print("exiting")
  # (B1) OPEN EXCEL FILE + WORKSHEET
  # book = load_workbook("s1_dummy.xlsx")
  # sheet = book.active
  # # first_column = sheet[0]
  # # (B2) PASS INTO HTML TEMPLATE
  # return render_template("s3_excel_table.html", sheet=sheet)
  # import pandas as pd
  # create dataframe
  #       print("hello there")
  #       data = pd.read_excel(r'C:\Users\saich\Desktop\quotation system\venv\templates\Quotationsystem_20220207.xlsx',
  #                            'Machining part',skiprows=2)
  #       data2 = pd.read_excel(r'C:\Users\saich\Desktop\quotation system\venv\templates\Quotationsystem_20220207.xlsx',
  #                            'Calculation_formula#1', skiprows=4)

        # data3 = pd.read_excel(r'C:\Users\saich\Desktop\quotation system\venv\templates\Quotation System_20220715.xlsm',
                              # 'Part List', skiprows=0)

        # r'C:\Users\saich\Desktop\quotation system\venv\templates\
        data3 = pd.read_excel('Quotation System_20220725.xlsm','Part List', skiprows=0)
        # r'C:\Users\saich\Desktop\quotation system\venv\templates\

        data4 = pd.read_excel('Quotation System_20220802.xlsm','Part List', skiprows=0)
        # r'C:\Users\saich\Desktop\quotation system\venv\templates\
        data5 = pd.read_excel('Quotation System_20220802.xlsm','Material Price per kg', skiprows=1)



        # QuotationSystem_20220725.xlsm

  # xls = pd.ExcelFile('path_to_file.xls')
  # df1 = pd.read_excel(xls, 'Sheet1')
  # df = pd.DataFrame(data)
  # & (df_marks['Machining Name_1'] == "VC630")
  #       df_marks = pd.DataFrame(data,columns= ['Manufacturer','Model','Part Number','Part Name_01','Material_Elements',
  #                                        'Material_Form','Material_Alloy','Metal Removal (kg)','Metal Removal Rate (kg/hr)',
  #                                        'Machining Name_1','Machining Hours_1','Machining Cost_1'])
        df_marks2 = pd.DataFrame(data3)
        df_marks3=pd.DataFrame(data3)
        df_marks4 = pd.DataFrame(data4)

        weightlist = df_marks3.iloc[:, 14].values.tolist()
        mytem1 = df_marks2.iloc[:, 9].values.tolist()
        mytem2 = df_marks2.iloc[:, 10].values.tolist()
        mytem3 = df_marks2.iloc[:, 8].values.tolist()
        mytem4 = df_marks2.iloc[:, 11].values.tolist()

        mynewlist1 = df_marks3.iloc[:, 20].values.tolist()
        mynewlist2 = df_marks3.iloc[:, 24].values.tolist()
        mynewlist3=[]
        mynewlist4 = df_marks3.iloc[:, 6].values.tolist()
        mynewlist5 = df_marks3.iloc[:, 5].values.tolist()
        mynewlist6 = df_marks3.iloc[:, 31].values.tolist()


        weightreflist = df_marks3.iloc[:, 30].values.tolist()



        machinelist1= df_marks3.iloc[:, 23].values.tolist()
        machineratelist2 = df_marks3.iloc[:, 25].values.tolist()

        dict2={}
        # print(machineratelist2)
        for x in range(0,len(machinelist1)):
            # print(machinelist1[x],machineratelist2[x],mynewlist6[x])
            # dict2[machinelist1[x]] = (str(machineratelist2[x]) + '@' + str(mynewlist6[x]))

            if machinelist1[x] in dict2:
                dict2[machinelist1[x]].append(str(machineratelist2[x])+'@'+str(mynewlist6[x]))
            else:
                dict2[machinelist1[x]] = [str(machineratelist2[x])+'@'+str(mynewlist6[x])]

        # print(dict2)

        # print(dict2[Machine_name2])

        graph2list = dict2[(Machine_name2).upper()]
        # print(graph2list)

        newxlist=[]
        newylist=[]
        for new in graph2list:
            tp = new.split('@')
            newylist.append(float(tp[0]))
            newxlist.append(int(tp[1]))

        mytem3 = mynewlist4
        mytem1 = mynewlist5
        mytem2 = mynewlist3
        mytem4 = mynewlist6

        # print("********************")
        # print(mynewlist1)
        # print("********************")

        # print("********************")
        # print(mynewlist2)
        # print("********************")

        # for val in range(0,len(mynewlist1)):
        #     mynewlist3.append(mynewlist1[val]/mynewlist2[val])

        templist2 = df_marks3.iloc[:, 22].values.tolist()
        mytem2 = templist2


        # print("********************")
        # print(mynewlist3)
        # print(templist2)
        # print(machinelist1)
        # print("********************")
        pet=[]
        for ter in mytem2:
            pet.append("{:.2f}".format(ter))
        mytem2 = pet
        # print(list(set(mytem3)))
        # print(mytem2)
        dict1={}
        # print(Category2 + Form2)
        # print("********************")
        # print(len(mytem1),len(mytem2),len(mytem3),len(mytem4))
        # print(templist2)
        # print("********************")
        myx = []
        for x in range(0,len(mytem1)):
            if mytem1[x]+'@'+mytem3[x] in dict1 and mytem1[x] == Category2 and mytem3[x] == Form2:
                dict1[mytem1[x]+'@'+mytem3[x]].append(str(weightlist[x])+'@'+str(mytem2[x]))
                # str(weightlist[x])
            elif mytem1[x]+'@'+mytem3[x] not in dict1 and mytem1[x] == Category2 and mytem3[x] == Form2:
                dict1[mytem1[x]+'@'+mytem3[x]] = [str(weightlist[x])+'@'+str(mytem2[x])]
            else:
                pass
        # print(dict1[Category2+Form2])
        # print(dict1[Category2+'@'+Form2])
        bar1list = []
        bar2list = []
        bar3list = []
        bar4list = []
        bar5list = []


        newgraph1dict = {}
        for pq in dict1[Category2+'@'+Form2]:
            pqsplit = pq.split('@')
            if weightref <= float(pqsplit[0]) < bar1:
                bar1list.append(float(pqsplit[1]))
            if bar1 <= float(pqsplit[0]) < bar2:
                bar2list.append(float(pqsplit[1]))
            if bar2 <= float(pqsplit[0]) < bar3:
                bar3list.append(float(pqsplit[1]))
            if bar3 <= float(pqsplit[0]) < bar4:
                bar4list.append(float(pqsplit[1]))
            if bar4 <= float(pqsplit[0]) < bar5:
                bar5list.append(float(pqsplit[1]))
        if len(bar1list) == 0:
            bar1listaverage = 0
        else:
            bar1listaverage= sum(bar1list)/len(bar1list)
        if len(bar2list) == 0:
            bar2listaverage = 0
        else:
            bar2listaverage= sum(bar2list)/len(bar2list)
        if len(bar3list) == 0:
            bar3listaverage = 0
        else:
            bar3listaverage= sum(bar3list)/len(bar3list)
        if len(bar4list) == 0:
            bar4listaverage = 0
        else:
            bar4listaverage= sum(bar4list)/len(bar4list)
        if len(bar5list) == 0:
            bar5listaverage = 0
        else:
            bar5listaverage= sum(bar5list)/len(bar5list)

        mygraph1average = (sum(bar1list) + sum(bar2list) + sum(bar3list) + sum(bar4list) + sum(bar5list)) / (
                    len(bar1list) +
                    len(bar2list) + len(bar3list) + len(bar4list) + len(bar5list))

        # print("average rate= " + str(
        # sum(dict1[Category2]) / len(dict1[Category2])))
        # plot.hist(weightList, density=1, bins=20)
        # plot.plot(dict1[Category2+Form2],'o')
        # plot.axis(Category2)
        # axis([xmin,xmax,ymin,ymax])

        xlist=[weightref+(delta),weightref+(2*delta),weightref+(3*delta),weightref+(4*delta),weightref+(5*delta)]
        ylist=[float("{:.2f}".format(bar1listaverage)),float("{:.2f}".format(bar2listaverage)),float("{:.2f}".format(bar3listaverage))
            ,float("{:.2f}".format(bar4listaverage)),float("{:.2f}".format(bar5listaverage))]
        print(xlist)
        print(ylist)
        # for x in dict1[Category2+'@'+Form2+'@'+str(weightrefout)]:
        #     p=x.split('@')
        #     print(p)
        #     xlist.append(int(float(p[1])))
        #     ylist.append(float(p[0]))
        # xi = list(range(len(x)))
        # te=sum(ylist)/len(ylist)
        # fig, ax = plot.subplots()
        # str(te)
        # plot.text(1, 1, 'Hello World !')

        # plot.xticks(xi, xlist)
        # , marker = 'o', linestyle = '--', color = 'r'
        # xlist=[]
        # for temper in range(0,len(ylist)):
        #     xlist.append(temper)
        fig, ax = plot.subplots()
        ax.scatter(xlist, ylist)

        # for i, txt in enumerate(ylist):
        #     ax.annotate(txt, (xlist[i], ylist[i]))
        # xint = range(math.floor(min(xlist)), math.ceil(max(xlist))+1)
        # xint = xlist
        # print(xlist,ylist)
        plot.xticks(xlist)
        plot.bar(xlist, ylist,color ='maroon',width = 10)

        for i, txt in enumerate(ylist):
            plot.annotate(txt, (xlist[i], ylist[i]))

        plot.xlabel('RM Weight(kg)')
        plot.ylabel('Metal Removal Rate ( kg/hr)')
        # if len(ylist)==1:
        #     myplot1stdev = "0"
        # else:
        #     myplot1stdev = str(format(statistics.stdev(ylist),".3f"))
        plot.title('average MRR' + '=' + str(float("{:.2f}".format(mygraph1average))) + '  kg/hr')
        # plot.xticks(range(min(xlist), max(ylist) + 1))
        # for i, v in enumerate(ylist):
        #     ax.text(v + 3, i + .25, str(v), color='blue', fontweight='bold')
        # plot.text(-5, 60, 'Graph1', fontsize=22)
        strFile = "temp.jpg"
        if os.path.isfile(strFile):
            # print("yes")
            os.remove(strFile)  # Opt.: os.system("rm "+strFile)
            # print("removed")
        # plot.savefig(strFile)

        plot.savefig('temp.jpg')
        # plot.savefig('temp.jpg',bbox_inches="tight",dpi=50)
        # plot.show()
        plot.close()

        import matplotlib.pyplot as plot2

# for fig2
        fig2, ax2 = plot2.subplots()
        ax2.scatter(newxlist, newylist)

        for i, txt in enumerate(newylist):
            ax2.annotate(txt, (newxlist[i], newylist[i]))
        newxint = range(math.floor(min(newxlist)), math.ceil(max(newxlist)) + 1)
        # xint = xlist
        # print(newxlist,newylist)
        plot2.xticks(newxint)
        plot2.bar(newxlist, newylist)
        plot2.xlabel('year')
        plot2.ylabel('Machine rate')
        if len(newylist)==1:
            myplot2stdev = "0"
        else:
            myplot2stdev = str(format(statistics.stdev(newylist),".3f"))
        plot2.title('average' + '=' + str(format((sum(newylist)/len(newylist)), ".3f")) + '      ' + 'median' + '=' +
                    str(statistics.median(newylist)) + '      ' +
                   'st deviation' + '=' + myplot2stdev)
        # plot.xticks(range(min(xlist), max(ylist) + 1))
        # for i, v in enumerate(ylist):
        #     ax.text(v + 3, i + .25, str(v), color='blue', fontweight='bold')
        # plot.text(-5, 60, 'Graph1', fontsize=22)
        strFile = "temp2.jpg"
        if os.path.isfile(strFile):
            # print("yes")
            os.remove(strFile)  # Opt.: os.system("rm "+strFile)
            # print("removed")
        # plot.savefig(strFile)

        plot2.savefig('temp2.jpg')
        # plot.savefig('temp.jpg',bbox_inches="tight",dpi=50)
        # plot.show()
        plot2.close()

        #fig2 ends

        # fig3 starts

        import matplotlib.pyplot as plot3

        myfig3tem1 = df_marks4.iloc[:, 5].values.tolist()
        myfig3tem2 = df_marks4.iloc[:, 6].values.tolist()
        myfig3tem3 = df_marks4.iloc[:, 7].values.tolist()
        myfig3tem4 = df_marks4.iloc[:, 9].values.tolist()
        myfig3tem5 = df_marks4.iloc[:, 15].values.tolist()
        if Category2=='Aluminium' and Form2 == 'Plate' and Alloy2 == str(7050) and Temper2 == 'T7451':
            finalmp = '5.91'
        elif Category2=='Aluminium' and Form2 == 'Plate' and Alloy2 == str(7075) and Temper2 == 'T7351':
            finalmp = '4.89'
        elif Category2=='Aluminium' and Form2 == 'Plate' and Alloy2 == str(7075) and Temper2 == 'T7451':
            finalmp = '5.91'
        elif Category2=='STEEL' and Form2 == 'Plate' and Alloy2 == str(304) and Temper2 == 'SOLUTION TREATED':
            finalmp = '15.90'
        elif Category2=='STEEL' and Form2 == 'Plate' and Alloy2 == "15-5PH" and Temper2 == 'ST':
            finalmp = '33.77'
        elif Category2=='Titanium' and Form2 == 'Plate' and Alloy2 == "TI-6AL-4V" and Temper2 == 'ANNEALED':
            finalmp = '38.93'
        else:
            finalmp = '0'

        mpxlist = [2000]
        mpylist = [float(finalmp)]

        fig2, ax2 = plot3.subplots()
        ax2.scatter(mpxlist, mpylist)

        # for i, txt in enumerate(ylist):
        #     ax.annotate(txt, (xlist[i], ylist[i]))
        # xint = range(math.floor(min(xlist)), math.ceil(max(xlist))+1)
        # xint = xlist
        # print(xlist,ylist)
        plot3.xticks(xlist)
        plot3.bar(mpxlist, mpylist, color='maroon', width=10)

        for i, txt in enumerate(mpylist):
            plot3.annotate(txt, (mpxlist[i], mpylist[i]))

        plot3.xlabel('year')
        plot3.ylabel('Meterial price ( $/kg)')

        plot3.title('Material price' + '=' + str(finalmp) + '  $/kg')
        # plot.xticks(range(min(xlist), max(ylist) + 1))
        # for i, v in enumerate(ylist):
        #     ax.text(v + 3, i + .25, str(v), color='blue', fontweight='bold')
        # plot.text(-5, 60, 'Graph1', fontsize=22)
        strFile = "temp3.jpg"
        if os.path.isfile(strFile):
            # print("yes")
            os.remove(strFile)  # Opt.: os.system("rm "+strFile)
            # print("removed")
        # plot.savefig(strFile)

        plot3.savefig('temp3.jpg')
        # plot.savefig('temp.jpg',bbox_inches="tight",dpi=50)
        # plot.show()
        plot3.close()

        # plot.show()
        # print(required_column1)
        # print(Manufacturer2)
        # print(Model2)
        f=1
        try:
            string_int = int(Model2)
        except ValueError:
            f=0
            pass
        if f==1:
            Model2 = int(Model2)
        f2 = 1
        try:
            string_int2 = int(Machine_name2)
        except ValueError:
            f2 = 0
            pass
        if f2 == 1:
            Machine_name2= int(Machine_name2)
        f3 = 1
        try:
            string_int3 = int(Alloy2)
        except ValueError:
            f3 = 0
            pass
        if f3 == 1:
            Alloy2 = int(Alloy2)
        # print(Machine_name2,type(Machine_name2))
        # df_marks=df_marks.loc[(df_marks['Manufacturer'] == Manufacturer2) & (df_marks['Model'] == Model2) &
        #                       ((df_marks['Machining Name_1'] == Machine_name2) | (df_marks['Machining Name_1'] == Machine_name2.upper())) &(df_marks['Material_Elements'] == Category2)
        #                       & (df_marks['Material_Form'] == Form2) & (df_marks['Material_Alloy'] == Alloy2)]
        #
        # df_marks=(df_marks.style.set_properties(**{'width': '2px','white-space': 'pre-wrap','text-align': 'left' , 'font-size': '7pt','border-color':'Black','border-width':'thin','border-style':'solid'}))
  # print(df_marks.columns)
  #       df_marks = df_marks.style.set_table_styles(
  #           [{"selector": "", "props": [("border", "1px solid grey")]},
  #            {"selector": "tbody td", "props": [("border", "1px solid grey")]},
  #            {"selector": "th", "props": [("border", "1px solid grey")]}
  #            ]
  #       )
  # df_marks = pd.DataFrame({'name': ['Somu', 'Kiku', 'Amol', 'Lini'],
  #                          'physics': [68, 74, 77, 78],
  #                          'chemistry': [84, 56, 73, 69],
  #                          'algebra': [78, 88, 82, 87]})

  # render dataframe as html
  #       im = Image.open("temp.jpg")
        # data = io.BytesIO()
        # im.save(data, "JPEG")
        # encoded_img_data = base64.b64encode(data.getvalue())
        # html = df_marks.to_html()
  # write html to file
  #       html = encoded_img_data.decode('utf-8')
  #       r"C:\Users\saich\Desktop\quotation system\venv\templates\
        text_file = open("templates\index.html", "w")
        html = """<html>
        <head>
        <style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 50%;
  padding: 0px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
        </head>
        <body>
        
        <div class="row">
  <div class="column">
  <h3>Metal removal rate</h3>
        <img src="../temp.jpg" height="280">  
  </div>
  <div class="column">
  <h3>Machine rate</h3>
        <img src="../temp2.jpg" height="280">
   
  </div>
</div>    
<div class="row">
  <div class="column">
  <h3>Material Price</h3>
        <img src="../temp3.jpg" height="280">
  
  </div>
  <div class="column">
  <h3>Treatment Price</h3>
        <img src="../temp2.jpg" height="280">
        
  </div>
</div>    
        </body>
        </html>"""
        text_file.write(html)
        # text_file.write(html)
        # print("writing done")
        text_file.close()
    # return render_template("index.html")
    return ('', 204)
@app.route('/success/<name>')
def success(name):
    a = name
    return 'quote data is is  %s' % name

@app.route('/login', methods=['POST', 'GET'])
def login():
    # print(temp)
    if request.method == 'POST':
        # user=request.form['nm']
        # user1 = request.form['nm1']
        Quote_no = request.form['Quote_no']
        Manufacturer=request.form['Manufacturer']
        # Manufacturer2 = request.form['Manufacturer2']
        Model=request.form['Model']
        Part_Number = request.form['Part_Number']
        Part_Name = request.form['Part_Name']
        Material = request.form['Material']
        form = request.form['Form']
        Alloy = request.form['Alloy']
        Temper = request.form['Temper']
        Profile = request.form['Profile']
        Part_Size_Thickness = request.form['Part_Size_Thickness']
        Part_Size_Width = request.form['Part_Size_Width']
        Part_Size_Length = request.form['Part_Size_Length']
        Part_Size_Weight = request.form['Part_Size_Weight']
        Raw_Material_Thickness = request.form['Raw_Material_Thickness']
        Raw_Material_Width = request.form['Raw_Material_Width']
        Raw_Material_Length = request.form['Raw_Material_Length']
        Raw_Material_Weight = request.form['Raw_Material_Weight']
        Metal_removal = request.form['Metal_removal']
        Removal_rate = request.form['Removal_rate']
        Machine_Hours = request.form['Machine_Hours']
        Machine_rate = request.form['Machine_rate']
        Machining_price = request.form['Machining_price']
        Material_dollar = request.form['Material_dollar']
        Material_price = request.form['Material_price']
        Treatment_Price = request.form['Treatment_Price']
        temp.append(Quote_no)
        temp.append(Manufacturer)
        temp.append(Model)
        temp.append(Part_Number)
        temp.append(Part_Name)
        temp.append(Material)
        temp.append(Alloy)
        temp.append(Temper)
        temp.append(Profile)
        temp.append(Part_Size_Thickness)
        temp.append(Part_Size_Width)
        temp.append(Part_Size_Length)
        temp.append(Part_Size_Weight)
        temp.append(Raw_Material_Thickness)
        temp.append(Raw_Material_Width)
        temp.append(Raw_Material_Length)
        temp.append(Raw_Material_Weight)
        temp.append(Metal_removal)
        temp.append(Removal_rate)
        temp.append(Machine_Hours)
        temp.append(Machine_rate)
        # temp.append(Machining_price)
        temp.append(Material_dollar)
        temp.append(Material_price)
        temp.append(Treatment_Price)
        # temp.append(Manufacturer2)
        # temp.append()
        # temp.append()
        # print(Manufacturer2)
        # user1=request.form['nm1']
        # + Machining_price + " "
        # + Machining_price + " "
        print(temp)
        time.sleep(10)
        #
        return redirect(url_for('success',
                                name=Quote_no + " " + Manufacturer+" " + Model + " " + Part_Number + " " +  Part_Name + " " + Material +
                                     " " + form + " " + Alloy + " " + Temper + " " +
                                     Profile + " " + Part_Size_Thickness + " " + Part_Size_Width + " " + Part_Size_Length +
                                     " " + Part_Size_Weight + " " + Raw_Material_Thickness + " " + Raw_Material_Width + " "
                                     + Raw_Material_Length + " " + Raw_Material_Weight + " " + Metal_removal + " " + Removal_rate + " " +
                                     Machine_Hours + " " + Machine_rate +  " " + Machining_price + " " + Material_dollar +" " + Material_price + " " +
                                     Treatment_Price))
        # return redirect(request.referrer)
    else:
        # user = request.args.get('nm')
        # user1 = request.args.get('nm1')
        # user1 = request.args.get('Quote_no')
        time.sleep(10)
        #
        return redirect(url_for('success',
                                name=Quote_no + " " + Manufacturer+" " + Model + " " + Part_Number + " " + Part_Name + " " +  Material +
                                     " "  + form + " " + Alloy + " " + Temper + " " + Profile + " " + Part_Size_Thickness + " " + Part_Size_Width + " " + Part_Size_Length +
                                     " " + Part_Size_Weight + " " + Raw_Material_Thickness + " " + Raw_Material_Width + " "
                                     + Raw_Material_Length + " " + Raw_Material_Weight + " " + Metal_removal + " " + Removal_rate + " "
                                     + Machine_Hours + " " + Machine_rate  + " " + Machining_price + " " + Material_dollar + " " + Material_price +
                                     " " + Treatment_Price))

        # return redirect(request.referrer)

if __name__ == '__main__':
    app.run(HOST_NAME, HOST_PORT,debug=True)